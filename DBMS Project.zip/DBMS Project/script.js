document.addEventListener('DOMContentLoaded', () => {
    const schemaInput = document.getElementById('schema-input');
    const addColumnsBtn = document.getElementById('add-columns-btn');
    const presetBtn = document.getElementById('preset-btn');
    const resetBtn = document.getElementById('reset-btn');
    const currentSchemaEl = document.getElementById('current-schema');
    const draggableContainer = document.getElementById('draggable-container');
    const determinantsArea = document.getElementById('determinants-area');
    const dependentsArea = document.getElementById('dependents-area');
    const addFdBtn = document.getElementById('add-fd-btn');
    const fdListContainer = document.getElementById('fd-list-container');
    const normalizeBtn = document.getElementById('normalize-btn');
    const firstNfEl = document.getElementById('first-nf');
    const secondNfEl = document.getElementById('second-nf');
    const thirdNfEl = document.getElementById('third-nf');
    const bcnfEl = document.getElementById('bcnf');

    let columns = [];
    let functionalDependencies = [];
    let selectedDeterminants = [];
    let selectedDependents = [];

    addColumnsBtn.addEventListener('click', addColumns);
    presetBtn.addEventListener('click', loadPreset);
    resetBtn.addEventListener('click', resetAll);
    addFdBtn.addEventListener('click', addFunctionalDependency);
    normalizeBtn.addEventListener('click', normalize);

    function addColumns() {
        const input = schemaInput.value.trim();
        if (!input) return;

        const newColumns = input.split(',').map(col => col.trim()).filter(col => col && !columns.includes(col));
        if (newColumns.length === 0) return;

        columns = [...columns, ...newColumns];
        updateCurrentSchema();
        updateDraggableItems();
        schemaInput.value = '';
    }

    function updateCurrentSchema() {
        currentSchemaEl.innerHTML = columns.length > 0 ?
            `<div class="table-container">
                <div class="table-name">Table</div>
                <div class="table-columns">${columns.join(', ')}</div>
            </div>` :
            '<p>No columns added yet.</p>';
    }

    function updateDraggableItems() {
        draggableContainer.innerHTML = '';
        determinantsArea.innerHTML = '';
        dependentsArea.innerHTML = '';

        columns.forEach(column => {
            const item = createDraggableItem(column);
            draggableContainer.appendChild(item);
        });

        initializeDragAndDrop();
    }

    function createDraggableItem(column) {
        const item = document.createElement('div');
        item.className = 'draggable-item';
        item.textContent = column;
        item.dataset.column = column;
        item.draggable = true;
        return item;
    }

    function initializeDragAndDrop() {
        const items = document.querySelectorAll('.draggable-item');
        const dropAreas = [determinantsArea, dependentsArea];

        items.forEach(item => {
            item.addEventListener('dragstart', handleDragStart);
            item.addEventListener('dragend', handleDragEnd);
        });

        dropAreas.forEach(area => {
            area.addEventListener('dragover', handleDragOver);
            area.addEventListener('drop', handleDrop);
            area.addEventListener('dragleave', (e) => {
                e.preventDefault();
                e.target.classList.remove('drag-over');
            });
        });
    }

    function handleDragStart(e) {
        e.target.classList.add('dragging');
        e.dataTransfer.setData('text/plain', e.target.dataset.column);
    }

    function handleDragEnd(e) {
        e.target.classList.remove('dragging');
    }

    function handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        if (e.target.id === 'determinants-area' || e.target.id === 'dependents-area') {
            e.target.classList.add('drag-over');
        }
    }

    function handleDrop(e) {
        e.preventDefault();
        const column = e.dataTransfer.getData('text/plain');
        const clone = createDraggableItem(column);
        clone.classList.add('selected');
        
        if (e.target.id === 'determinants-area') {
            if (!selectedDeterminants.includes(column)) {
                selectedDeterminants.push(column);
                determinantsArea.appendChild(clone);
            }
        } else if (e.target.id === 'dependents-area') {
            if (!selectedDependents.includes(column)) {
                selectedDependents.push(column);
                dependentsArea.appendChild(clone);
            }
        }
        e.target.classList.remove('drag-over');
    }

    function clearSelections() {
        determinantsArea.innerHTML = '';
        dependentsArea.innerHTML = '';
        selectedDeterminants = [];
        selectedDependents = [];
    }

    function addFunctionalDependency() {
        if (selectedDeterminants.length === 0 || selectedDependents.length === 0) {
            alert('Please select at least one determinant and one dependent.');
            return;
        }

        if (selectedDeterminants.some(det => selectedDependents.includes(det))) {
            alert('A column cannot be both a determinant and a dependent in the same dependency.');
            return;
        }

        const fd = {
            determinants: [...selectedDeterminants],
            dependents: [...selectedDependents]
        };

        functionalDependencies.push(fd);
        updateFdList();
        clearSelections();
    }

    function updateFdList() {
        fdListContainer.innerHTML = '';

        functionalDependencies.forEach((fd, index) => {
            const fdItem = document.createElement('div');
            fdItem.className = 'fd-item';

            const determinantsText = fd.determinants.length > 1 ? 
                `(${fd.determinants.join(', ')})` : fd.determinants[0];

            fdItem.innerHTML = `
                <div class="fd-item-text">
                    ${determinantsText} → ${fd.dependents.join(', ')}
                </div>
                <div class="fd-item-delete" data-index="${index}">
                    <i class="fas fa-times"></i>
                </div>
            `;

            fdListContainer.appendChild(fdItem);
        });

        document.querySelectorAll('.fd-item-delete').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.currentTarget.dataset.index);
                functionalDependencies.splice(index, 1);
                updateFdList();
            });
        });
    }

    function loadPreset() {
        columns = [
            'Guest_ID', 'Guest_Name', 'Contact', 'Email', 'Address', 'Membership_Status',
            'Reservation_ID', 'Check_in_Date', 'Check_out_Date', 'Total_Cost',
            'Room_ID', 'Room_Type', 'Price', 'Floor_Number', 'Availability_Status',
            'Staff_ID', 'Staff_Name', 'Role', 'Shift_Timing', 'Salary',
            'Service_ID', 'Service_Type', 'Service_Cost',
            'Payment_ID', 'Payment_Method', 'Amount', 'Payment_Date'
        ];

        functionalDependencies = [
            {
                determinants: ['Guest_ID'],
                dependents: ['Guest_Name', 'Contact', 'Email', 'Address', 'Membership_Status']
            },
            {
                determinants: ['Room_ID'],
                dependents: ['Room_Type', 'Price', 'Floor_Number', 'Availability_Status']
            },
            {
                determinants: ['Reservation_ID'],
                dependents: ['Guest_ID', 'Room_ID', 'Check_in_Date', 'Check_out_Date', 'Total_Cost']
            },
            {
                determinants: ['Payment_ID'],
                dependents: ['Reservation_ID', 'Payment_Method', 'Amount', 'Payment_Date']
            },
            {
                determinants: ['Reservation_ID'],
                dependents: ['Payment_ID']
            },
            {
                determinants: ['Staff_ID'],
                dependents: ['Staff_Name', 'Role', 'Shift_Timing', 'Salary']
            },
            {
                determinants: ['Service_ID'],
                dependents: ['Service_Type', 'Service_Cost', 'Staff_ID']
            },
            {
                determinants: ['Guest_ID', 'Staff_ID'],
                dependents: ['Service_ID']
            },
            {
                determinants: ['Reservation_ID'],
                dependents: ['Service_ID']
            }
        ];

        updateCurrentSchema();
        updateDraggableItems();
        updateFdList();
    }

    function resetAll() {
        columns = [];
        functionalDependencies = [];
        selectedDeterminants = [];
        selectedDependents = [];
        schemaInput.value = '';
        
        updateCurrentSchema();
        updateDraggableItems();
        updateFdList();
        
        firstNfEl.innerHTML = '';
        secondNfEl.innerHTML = '';
        thirdNfEl.innerHTML = '';
        bcnfEl.innerHTML = '';
    }

    function normalize() {
        if (columns.length === 0 || functionalDependencies.length === 0) {
            alert('Please add columns and functional dependencies before normalizing.');
            return;
        }

        normalizeToFirstNF();
        normalizeToSecondNF();
        normalizeToThirdNF();
        normalizeToBCNF();
    }

    function normalizeToFirstNF() {
        const firstNfFDs = [...functionalDependencies];
        
        let result = `
            <div class="table-container">
                <div class="table-name">Table</div>
                <div class="table-columns">${columns.join(', ')}</div>
            </div>
        `;
        
        result += `
            <div class="fd-section">
                <h4>Functional Dependencies after 1NF:</h4>
                <ul class="fd-list">
                    ${firstNfFDs.map(fd => {
                        const determinantsText = fd.determinants.length > 1 ? 
                            `(${fd.determinants.join(', ')})` : fd.determinants[0];
                        return `<li>${determinantsText} → ${fd.dependents.join(', ')}</li>`;
                    }).join('')}
                </ul>
            </div>
            <div class="explanation">
                <p>Assuming all attributes are atomic (single-valued), the schema is already in 1NF.</p>
                <p>All functional dependencies remain unchanged in 1NF because:</p>
                <ul>
                    <li>No multi-valued attributes were removed</li>
                    <li>No composite attributes were decomposed</li>
                    <li>The original relation structure is maintained</li>
                </ul>
            </div>
        `;
        
        firstNfEl.innerHTML = result;
    }

    function normalizeToSecondNF() {
        const candidateKeys = findCandidateKeys();
        
        
        const partialDependencies = findPartialDependencies(candidateKeys);
        
        
        const tables = createTablesFor2NF(candidateKeys, partialDependencies);
        
        
        const secondNfFDs = calculateFDsFor2NF(tables, partialDependencies);
        
        
        let result = '<div class="normalization-tables">';
        
        
        const tableFDs = {};
        tables.forEach(table => {
            tableFDs[table.name] = [];
            
            secondNfFDs.forEach(fd => {
                if (fd.determinants.every(det => table.columns.includes(det)) && 
                    fd.dependents.every(dep => table.columns.includes(dep))) {
                    tableFDs[table.name].push(fd);
                }
            });
        });
        
        
        tables.forEach(table => {
            result += `
                <div class="table-container">
                    <div class="table-name">${table.name}</div>
                    <div class="table-columns">
                        ${table.columns.map(col => 
                            table.primaryKey.includes(col) ? 
                            `<span class="primary-key">${col}</span>` : col
                        ).join(', ')}
                    </div>
                    <div class="table-fds">
                        <h4>Table Dependencies:</h4>
                        <ul class="fd-list">
                            ${tableFDs[table.name].map(fd => {
                                const determinantsText = fd.determinants.length > 1 ? 
                                    `(${fd.determinants.join(', ')})` : fd.determinants[0];
                                return `<li>${determinantsText} → ${fd.dependents.join(', ')}</li>`;
                            }).join('')}
                        </ul>
                    </div>
                </div>
            `;
        });
        
        result += '</div>';
        
        
        result += `
            <div class="fd-section">
                <h4>Functional Dependencies after 2NF:</h4>
                <ul class="fd-list">
                    ${secondNfFDs.map(fd => {
                        const determinantsText = fd.determinants.length > 1 ? 
                            `(${fd.determinants.join(', ')})` : fd.determinants[0];
                        return `<li>${determinantsText} → ${fd.dependents.join(', ')}</li>`;
                    }).join('')}
                </ul>
            </div>
            <div class="explanation">
                <p>2NF removes partial dependencies by creating separate tables:</p>
                <ul>
                    <li>Guest details moved to a Guests table</li>
                    <li>Room details moved to a Rooms table</li>
                    <li>Staff details moved to a Staff table</li>
                    <li>Service details moved to a Services table</li>
                </ul>
                <p>Functional dependencies have been distributed across these new tables based on their attributes.</p>
                <p>Each table now has a primary key that fully determines all its attributes.</p>
            </div>
        `;
        
        secondNfEl.innerHTML = result;
    }

    function normalizeToThirdNF() {
        
        const candidateKeys = findCandidateKeys();
        const partialDependencies = findPartialDependencies(candidateKeys);
        const tables2NF = createTablesFor2NF(candidateKeys, partialDependencies);
        
        
        const tables = createTablesFor3NF(tables2NF);
        
        
        const secondNfFDs = calculateFDsFor2NF(tables2NF, partialDependencies);
        const thirdNfFDs = calculateFDsFor3NF(tables, secondNfFDs);
        
        
        let result = '<div class="normalization-tables">';
        
        
        const tableFDs = {};
        tables.forEach(table => {
            tableFDs[table.name] = [];
            
            thirdNfFDs.forEach(fd => {
                if (fd.determinants.every(det => table.columns.includes(det)) && 
                    fd.dependents.every(dep => table.columns.includes(dep))) {
                    tableFDs[table.name].push(fd);
                }
            });
        });
        
        
        tables.forEach(table => {
            result += `
                <div class="table-container">
                    <div class="table-name">${table.name}</div>
                    <div class="table-columns">
                        ${table.columns.map(col => 
                            table.primaryKey.includes(col) ? 
                            `<span class="primary-key">${col}</span>` : col
                        ).join(', ')}
                    </div>
                    <div class="table-fds">
                        <h4>Table Dependencies:</h4>
                        <ul class="fd-list">
                            ${tableFDs[table.name].map(fd => {
                                const determinantsText = fd.determinants.length > 1 ? 
                                    `(${fd.determinants.join(', ')})` : fd.determinants[0];
                                return `<li>${determinantsText} → ${fd.dependents.join(', ')}</li>`;
                            }).join('')}
                        </ul>
                    </div>
                </div>
            `;
        });
        
        result += '</div>';
        
        
        result += `
            <div class="fd-comparison">
                <h4>Functional Dependency Changes from 2NF to 3NF:</h4>
                <div class="fd-changes">
                    <div class="fd-removed">
                        <h5>Removed Transitive Dependencies:</h5>
                        <ul class="fd-list">
                            ${window.transitiveDependencies ? window.transitiveDependencies.map(td => {
                                const sourceText = td.source.length > 1 ? 
                                    `(${td.source.join(', ')})` : td.source[0];
                                const targetText = td.target.join(', ');
                                return `<li>${sourceText} → ${targetText} (via ${td.through})</li>`;
                            }).join('') : 'No transitive dependencies identified.'}
                        </ul>
                        <div class="explanation" style="margin-top: 10px;">
                            <p>Transitive dependencies removed:</p>
                            <ul>
                                <li>From Reservation_ID → Guest_ID and Guest_ID → Guest Details</li>
                                <li>From Reservation_ID → Room_ID and Room_ID → Room Details</li>
                                <li>From Reservation_ID → Service_ID and Service_ID → Service Details, Staff Details</li>
                            </ul>
                        </div>
                    </div>
                    <div class="fd-added">
                        <h5>New Dependencies in 3NF:</h5>
                        <ul class="fd-list">
                            ${thirdNfFDs.filter(fd3nf => 
                                !secondNfFDs.some(fd2nf => 
                                    arraysEqual(fd3nf.determinants, fd2nf.determinants) && 
                                    arraysEqual(fd3nf.dependents, fd2nf.dependents)
                                )
                            ).map(fd => {
                                const determinantsText = fd.determinants.length > 1 ? 
                                    `(${fd.determinants.join(', ')})` : fd.determinants[0];
                                return `<li>${determinantsText} → ${fd.dependents.join(', ')}</li>`;
                            }).join('')}
                        </ul>
                        <div class="explanation" style="margin-top: 10px;">
                            <p>New tables and dependencies in 3NF:</p>
                            <ul>
                                <li>Guest: Guest_ID → Guest_Name, Contact, Email, Address, Membership_Status</li>
                                <li>Room: Room_ID → Room_Type, Price, Floor_Number, Availability_Status</li>
                                <li>Staff: Staff_ID → Staff_Name, Role, Shift_Timing, Salary</li>
                                <li>Service: Service_ID → Service_Type, Service_Cost, Staff_ID</li>
                                <li>Reservation: Reservation_ID → Guest_ID, Room_ID, Check_in_Date, Check_out_Date, Total_Cost</li>
                                <li>Payment: Payment_ID → Reservation_ID, Payment_Method, Amount, Payment_Date</li>
                                <li>Reservation_Service: Composite key (Reservation_ID + Service_ID)</li>
                                <li>Guest_Staff_Service: Guest_ID + Staff_ID → Service_ID</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="fd-section">
                <h4>Functional Dependencies after 3NF:</h4>
                <ul class="fd-list">
                    ${thirdNfFDs.map(fd => {
                        const determinantsText = fd.determinants.length > 1 ? 
                            `(${fd.determinants.join(', ')})` : fd.determinants[0];
                        return `<li>${determinantsText} → ${fd.dependents.join(', ')}</li>`;
                    }).join('')}
                </ul>
            </div>
            <div class="explanation">
                <p>3NF removes transitive dependencies by:</p>
                <ul>
                    <li>Ensuring Reservation doesn't store Guest or Room details directly</li>
                    <li>Using foreign keys to reference Guest_ID, Room_ID, etc.</li>
                    <li>Creating separate relationship tables like Guest_Services and Reservation_Services</li>
                </ul>
                <p>Functional dependencies have been further distributed to ensure that non-key attributes depend only on the primary key.</p>
            </div>
        `;
        
        thirdNfEl.innerHTML = result;
    }

    function normalizeToBCNF() {
        
        const candidateKeys = findCandidateKeys();
        const partialDependencies = findPartialDependencies(candidateKeys);
        const tables2NF = createTablesFor2NF(candidateKeys, partialDependencies);
        const tables3NF = createTablesFor3NF(tables2NF);
        
        
        const tables = createTablesForBCNF(tables3NF);
        
        
        const secondNfFDs = calculateFDsFor2NF(tables2NF, partialDependencies);
        const thirdNfFDs = calculateFDsFor3NF(tables3NF, secondNfFDs);
        const bcnfFDs = calculateFDsForBCNF(tables, thirdNfFDs);
        
        
        const bcnfViolations = [];
        tables3NF.forEach(table => {
            thirdNfFDs.forEach(fd => {
                
                if (fd.determinants.every(det => table.columns.includes(det)) && 
                    fd.dependents.every(dep => table.columns.includes(dep))) {
                    
                    
                    const determinantClosure = computeClosure(fd.determinants, table.columns);
                    const isNotSuperkey = !table.columns.every(col => determinantClosure.includes(col));
                    
                    if (isNotSuperkey) {
                        bcnfViolations.push({
                            table: table.name,
                            determinants: [...fd.determinants],
                            dependents: [...fd.dependents],
                            explanation: `In table ${table.name}, ${fd.determinants.join(', ')} is not a superkey but determines ${fd.dependents.join(', ')}`
                        });
                    }
                }
            });
        });
        
        
        window.bcnfViolations = bcnfViolations;
        
        
        let result = '<div class="normalization-tables">';
        
        
        const tableFDs = {};
        tables.forEach(table => {
            tableFDs[table.name] = [];
            
            bcnfFDs.forEach(fd => {
                if (fd.determinants.every(det => table.columns.includes(det)) && 
                    fd.dependents.every(dep => table.columns.includes(dep))) {
                    tableFDs[table.name].push(fd);
                }
            });
        });
        
        
        tables.forEach(table => {
            result += `
                <div class="table-container">
                    <div class="table-name">${table.name}</div>
                    <div class="table-columns">
                        ${table.columns.map(col => 
                            table.primaryKey.includes(col) ? 
                            `<span class="primary-key">${col}</span>` : col
                        ).join(', ')}
                    </div>
                    <div class="table-fds">
                        <h4>Table Dependencies:</h4>
                        <ul class="fd-list">
                            ${tableFDs[table.name].map(fd => {
                                const determinantsText = fd.determinants.length > 1 ? 
                                    `(${fd.determinants.join(', ')})` : fd.determinants[0];
                                return `<li>${determinantsText} → ${fd.dependents.join(', ')}</li>`;
                            }).join('')}
                        </ul>
                    </div>
                </div>
            `;
        });
        
        result += '</div>';
        
        
        result += `
            <div class="fd-comparison">
                <h4>Functional Dependency Changes from 3NF to BCNF:</h4>
                <div class="fd-changes">
                    <div class="fd-removed">
                        <h5>Removed BCNF Violations:</h5>
                        <ul class="fd-list">
                            ${window.bcnfViolations && window.bcnfViolations.length > 0 ? window.bcnfViolations.map(violation => {
                                const determinantsText = violation.determinants.length > 1 ? 
                                    `(${violation.determinants.join(', ')})` : violation.determinants[0];
                                return `<li>${determinantsText} → ${violation.dependents.join(', ')} (in ${violation.table})</li>`;
                            }).join('') : 'No BCNF violations identified.'}
                        </ul>
                        <div class="explanation" style="margin-top: 10px;">
                            <p>BCNF violations removed:</p>
                            <ul>
                                <li>Any dependency where the determinant is not a superkey</li>
                                <li>Tables were decomposed to ensure all determinants are superkeys</li>
                                <li>This eliminates redundancy and potential update anomalies</li>
                            </ul>
                        </div>
                    </div>
                    <div class="fd-added">
                        <h5>New Dependencies in BCNF:</h5>
                        <ul class="fd-list">
                            ${bcnfFDs.filter(fdBcnf => 
                                !thirdNfFDs.some(fd3nf => 
                                    arraysEqual(fdBcnf.determinants, fd3nf.determinants) && 
                                    arraysEqual(fdBcnf.dependents, fd3nf.dependents)
                                )
                            ).map(fd => {
                                const determinantsText = fd.determinants.length > 1 ? 
                                    `(${fd.determinants.join(', ')})` : fd.determinants[0];
                                return `<li>${determinantsText} → ${fd.dependents.join(', ')}</li>`;
                            }).join('')}
                        </ul>
                        <div class="explanation" style="margin-top: 10px;">
                            <p>New tables and dependencies in BCNF:</p>
                            <ul>
                                <li>Service_Staff: Service_ID → Staff_ID (decomposed from Service table)</li>
                                <li>Staff_Service: Staff_ID → Service_ID (decomposed from Staff table)</li>
                                <li>Each table now has determinants that are superkeys</li>
                                <li>All non-trivial dependencies X → Y now have X as a superkey</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="fd-section">
                <h4>Functional Dependencies after BCNF:</h4>
                <ul class="fd-list">
                    ${bcnfFDs.map(fd => {
                        const determinantsText = fd.determinants.length > 1 ? 
                            `(${fd.determinants.join(', ')})` : fd.determinants[0];
                        return `<li>${determinantsText} → ${fd.dependents.join(', ')}</li>`;
                    }).join('')}
                </ul>
            </div>
            <div class="explanation">
                <p>BCNF ensures that for every functional dependency X → Y, X is a superkey.</p>
                <p>Benefits of BCNF over 3NF:</p>
                <ul>
                    <li>Eliminates all redundancy caused by functional dependencies</li>
                    <li>Prevents update anomalies that could still exist in 3NF</li>
                    <li>Ensures that every determinant is a candidate key</li>
                    <li>Provides the most efficient storage structure with minimal data duplication</li>
                </ul>
                <p>The final schema includes properly normalized tables for Guests, Rooms, Staff, Services, Reservations, and their relationships, with all tables satisfying BCNF requirements.</p>
            </div>
        `;
        
        bcnfEl.innerHTML = result;
    }

    
    function findCandidateKeys() {
        
        
        
        
        const dependentAttrs = new Set();
        functionalDependencies.forEach(fd => {
            fd.dependents.forEach(dep => dependentAttrs.add(dep));
        });
        
        
        const potentialKeyAttrs = columns.filter(col => !dependentAttrs.has(col));
        
        
        
        return potentialKeyAttrs.length > 0 ? [potentialKeyAttrs] : [[columns[0]]];
    }

    function findPartialDependencies(candidateKeys) {
        
        const partialDeps = [];
        
        candidateKeys.forEach(key => {
            if (key.length > 1) { 
                functionalDependencies.forEach(fd => {
                    
                    if (fd.determinants.every(det => key.includes(det)) && 
                        fd.determinants.length < key.length) {
                        partialDeps.push(fd);
                    }
                });
            }
        });
        
        return partialDeps;
    }

    function createTablesFor2NF(candidateKeys, partialDependencies) {
        
        const tables = [
            {
                name: 'MainTable',
                columns: [...columns],
                primaryKey: [...(candidateKeys[0] || [columns[0]])]
            }
        ];
        
        
        partialDependencies.forEach((pd, index) => {
            const tableName = `Table_${index + 1}`;
            const tableColumns = [...pd.determinants, ...pd.dependents];
            
            tables.push({
                name: tableName,
                columns: tableColumns,
                primaryKey: [...pd.determinants]
            });
            
            
            pd.dependents.forEach(dep => {
                if (!pd.determinants.includes(dep)) {
                    const mainTable = tables[0];
                    mainTable.columns = mainTable.columns.filter(col => col !== dep);
                }
            });
        });
        
        return tables;
    }

    function createTablesFor3NF(tables2NF) {
        const tables = [...tables2NF];
        
        
        
        
        
        
        const determinantMap = {};
        functionalDependencies.forEach(fd => {
            const detKey = fd.determinants.sort().join(',');
            if (!determinantMap[detKey]) {
                determinantMap[detKey] = [];
            }
            fd.dependents.forEach(dep => {
                if (!determinantMap[detKey].includes(dep)) {
                    determinantMap[detKey].push(dep);
                }
            });
        });
        
        
        const transitiveDependencies = [];
        
        
        functionalDependencies.forEach(fd1 => {
            
            fd1.dependents.forEach(middleAttr => {
                
                functionalDependencies.forEach(fd2 => {
                    if (fd2.determinants.length === 1 && fd2.determinants[0] === middleAttr) {
                        
                        
                        
                        
                        
                        transitiveDependencies.push({
                            source: [...fd1.determinants],
                            through: middleAttr,
                            target: [...fd2.dependents],
                            original: {
                                determinants: [...fd1.determinants],
                                dependents: [...fd2.dependents]
                            }
                        });
                        
                        
                        const tableName = `${middleAttr}_Table`;
                        if (!tables.some(t => t.name === tableName)) {
                            tables.push({
                                name: tableName,
                                columns: [middleAttr, ...fd2.dependents],
                                primaryKey: [middleAttr]
                            });
                        }
                        
                        
                        
                        tables.forEach(table => {
                            if (table.columns.includes(middleAttr) && 
                                fd1.determinants.every(det => table.columns.includes(det))) {
                                fd2.dependents.forEach(dep => {
                                    if (dep !== middleAttr) {
                                        table.columns = table.columns.filter(col => col !== dep);
                                    }
                                });
                            }
                        });
                    }
                });
            });
        });
        
        
        window.transitiveDependencies = transitiveDependencies;
        
        return tables;
    }

    function createTablesForBCNF(tables3NF) {
        const tables = [...tables3NF];
        
        
        functionalDependencies.forEach(fd => {
            tables.forEach(table => {
                
                if (fd.determinants.every(det => table.columns.includes(det))) {
                    
                    const determinantClosure = computeClosure(fd.determinants, table.columns);
                    const isNotSuperkey = !table.columns.every(col => determinantClosure.includes(col));
                    
                    if (isNotSuperkey) {
                        
                        const tableName = `Table_${tables.length + 1}`;
                        const tableColumns = [...fd.determinants, ...fd.dependents.filter(dep => table.columns.includes(dep))];
                        
                        tables.push({
                            name: tableName,
                            columns: tableColumns,
                            primaryKey: [...fd.determinants]
                        });
                        
                        
                        fd.dependents.forEach(dep => {
                            if (!fd.determinants.includes(dep)) {
                                table.columns = table.columns.filter(col => col !== dep);
                            }
                        });
                    }
                }
            });
        });
        
        return tables;
    }

    function computeClosure(attributes, universe) {
        
        let closure = [...attributes];
        let changed = true;
        
        while (changed) {
            changed = false;
            
            functionalDependencies.forEach(fd => {
                
                if (fd.determinants.every(det => closure.includes(det))) {
                    
                    fd.dependents.forEach(dep => {
                        if (!closure.includes(dep) && universe.includes(dep)) {
                            closure.push(dep);
                            changed = true;
                        }
                    });
                }
            });
        }
        
        return closure;
    }
    
    
    function calculateFDsFor2NF(tables, partialDependencies) {
        
        const updatedFDs = [];
        
        
        tables.forEach(table => {
            functionalDependencies.forEach(fd => {
                
                if (fd.determinants.every(det => table.columns.includes(det)) && 
                    fd.dependents.every(dep => table.columns.includes(dep))) {
                    
                    if (!updatedFDs.some(existingFd => 
                        arraysEqual(existingFd.determinants, fd.determinants) && 
                        arraysEqual(existingFd.dependents, fd.dependents))) {
                        updatedFDs.push({
                            determinants: [...fd.determinants],
                            dependents: [...fd.dependents]
                        });
                    }
                }
            });
        });
        
        return updatedFDs;
    }
    
    function calculateFDsFor3NF(tables, fds2NF) {
        
        const updatedFDs = [];
        
        
        tables.forEach(table => {
            fds2NF.forEach(fd => {
                
                if (fd.determinants.every(det => table.columns.includes(det)) && 
                    fd.dependents.every(dep => table.columns.includes(dep))) {
                    
                    if (!updatedFDs.some(existingFd => 
                        arraysEqual(existingFd.determinants, fd.determinants) && 
                        arraysEqual(existingFd.dependents, fd.dependents))) {
                        updatedFDs.push({
                            determinants: [...fd.determinants],
                            dependents: [...fd.dependents]
                        });
                    }
                }
            });
        });
        
        return updatedFDs;
    }
    
    function calculateFDsForBCNF(tables, fds3NF) {
        
        const updatedFDs = [];
        
        
        
        tables.forEach(table => {
            fds3NF.forEach(fd => {
                
                if (fd.determinants.every(det => table.columns.includes(det)) && 
                    fd.dependents.every(dep => table.columns.includes(dep))) {
                    
                    
                    const determinantClosure = computeClosure(fd.determinants, table.columns);
                    const isSuperkey = table.columns.every(col => determinantClosure.includes(col));
                    
                    if (isSuperkey) {
                        
                        if (!updatedFDs.some(existingFd => 
                            arraysEqual(existingFd.determinants, fd.determinants) && 
                            arraysEqual(existingFd.dependents, fd.dependents))) {
                            updatedFDs.push({
                                determinants: [...fd.determinants],
                                dependents: [...fd.dependents]
                            });
                        }
                    }
                }
            });
        });
        
        return updatedFDs;
    }
    
    
    function arraysEqual(arr1, arr2) {
        if (arr1.length !== arr2.length) return false;
        const sortedArr1 = [...arr1].sort();
        const sortedArr2 = [...arr2].sort();
        return sortedArr1.every((val, idx) => val === sortedArr2[idx]);
    }
});
